# Guia de instalação e permissões — J.A.R.V.I.S. Nova 1.3.4

## Estado real da versão

Este pacote é código-fonte, não um APK já compilado. O APK só estará disponível depois que o workflow do GitHub Actions terminar com sucesso.

- Conversa com IA: depende de internet e de uma chave válida do provedor configurado.
- Microfone manual: depende de permissão de gravação de áudio.
- Voz falada: depende do mecanismo TTS disponível no Android e do idioma instalado.
- Ativação contínua por “Jarvis”: exige integração Porcupine funcional e AccessKey Picovoice válida. Sem isso, use o botão do microfone.
- Notificações: o usuário precisa habilitar manualmente o acesso especial nas configurações do Android. O acesso pode expor conteúdo sensível das notificações; habilite apenas se quiser.
- SMS: este pacote não deve ser considerado leitor/envia-SMS completo. Ler SMS diretamente exige implementação dedicada, permissões/fluxos adicionais e pode estar sujeito a restrições de distribuição.
- Chamadas, WhatsApp e outros aplicativos: a integração abre fluxos permitidos pelo Android; não garante controle total de interfaces de terceiros.
- Alarmes: podem exigir permissão especial para alarmes exatos, dependendo da versão do Android.

## Instalar o APK debug

1. No GitHub, abra o repositório e selecione **Actions**.
2. Abra a execução mais recente de **Build e testes do J.A.R.V.I.S. Nova**.
3. Aguarde o estado **Success**. Se falhar, abra o job e consulte a primeira tarefa vermelha e o log completo.
4. Em **Artifacts**, baixe `JARVIS-Nova-1.3.4-APK` e extraia o arquivo ZIP.
5. Transfira `app-debug.apk` para o celular.
6. Abra o arquivo no celular e, se solicitado, permita temporariamente a instalação dessa fonte em **Configurações → Segurança/Apps → Instalar apps desconhecidos**.
7. Instale e abra o J.A.R.V.I.S. Nova. Se o Android avisar que o app não foi verificado, só continue se você tiver baixado o artefato diretamente do seu próprio repositório.
8. Conceda o microfone quando solicitado.

## Permissões especiais opcionais

- **Acesso às notificações:** Configurações → Notificações → Acesso às notificações → J.A.R.V.I.S. Nova. O nome do menu varia por fabricante.
- **Bateria:** Configurações → Aplicativos → J.A.R.V.I.S. Nova → Bateria. “Sem restrições” pode ajudar em segundo plano, mas aumenta o consumo e não garante execução contínua.
- **Alarmes e lembretes:** habilite somente se o Android solicitar e você quiser alarmes exatos.
- **Contatos:** conceda somente se usar comandos que consultem contatos.

Não habilite Acessibilidade, administrador do dispositivo, acesso a SMS ou outras permissões amplas sem uma função concreta e explicação. Permissões não removem as limitações do Android nem garantem execução permanente em segundo plano.

## Checklist de teste após instalar

- [ ] Abrir o app sem falha.
- [ ] Conceder microfone e testar gravação/transcrição.
- [ ] Configurar uma chave de IA e confirmar resposta com internet.
- [ ] Testar voz falada e interrupção da fala.
- [ ] Testar notificação somente após habilitar o acesso especial.
- [ ] Criar alarme de teste para alguns minutos à frente.
- [ ] Testar abertura de aplicativo e controle de mídia.
- [ ] Testar segundo plano e reinicialização; registrar fabricante, versão Android e resultado.
- [ ] Verificar consumo de bateria antes de deixar escuta contínua habilitada.

## Se o build falhar

Não instale um artefato de uma execução falha. Copie a primeira mensagem `FAILURE:` e as linhas `Could not find`, `Could not resolve` ou `error:` do log para diagnóstico.
