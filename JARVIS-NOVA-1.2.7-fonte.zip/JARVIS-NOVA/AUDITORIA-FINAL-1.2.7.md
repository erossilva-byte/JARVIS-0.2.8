# Auditoria final — J.A.R.V.I.S. Nova 1.2.7

Data: 2026-10-16  
Base: `JARVIS-NOVA-1.2.5-fonte(1).zip`, evoluída para 1.2.7.

## Resultado

A revisão estática foi concluída. Foram corrigidos três pontos antes de entregar esta fonte para um novo repositório:

1. **Bloqueio no workflow:** o comando `find ... -exec` tinha duas barras invertidas antes do ponto e vírgula no YAML; o shell poderia interpretar o ponto e vírgula como separador de comandos e interromper a extração. Corrigido para um escape de shell correto e incluído em teste de prontidão.
2. **Rótulos da ativação por voz:** a interface indicava “Jarvis”, embora o modelo configurado seja “Hey Jarvis”. O texto foi alinhado ao modelo real.
3. **Proteção das chaves no Android:** o app não deve salvar novas chaves em `localStorage` em texto puro se o cofre nativo falhar. O salvamento agora falha com mensagem explícita; uma chave antiga em texto puro só é migrada se o cofre aceitar a gravação, caso contrário é removida e o usuário é avisado para cadastrá-la novamente.

Também foi ajustado o script de versão para não falhar se for executado de novo quando `versionCode` e `versionName` já estiverem corretos, e a documentação de `patch_visual.py` deixou de prometer que o APK será gerado “de qualquer jeito”.

## Verificações realizadas

- `npm run test:all`: aprovado após as correções.
- `node --check` para `app.js`, `main.js` e `apps.js`: aprovado.
- Teste de rotas de voz do WhatsApp: aprovado para abertura segura da conversa.
- Validador de estrutura: 142 IDs HTML únicos; nenhuma referência literal a ID inexistente identificada pelo validador.
- Teste de patch Gradle: API mínima 26, dependência openWakeWord e JitPack sem duplicação.
- Novo teste de prontidão: workflow, rótulos de ativação, versão e falha segura do cofre verificados.
- `py_compile` dos scripts Python: aprovado.
- ZIP: teste de integridade sem erros.
- Interface: HTML, CSS responsivo, estrutura dos painéis, estados visuais, acessibilidade básica e controles foram revisados estaticamente. Não foi possível obter uma captura renderizada confiável neste ambiente; a inspeção visual final em emulador/aparelho continua pendente.

## Pendências que não podem ser certificadas por testes estáticos

1. **Build real:** não foi executado um `assembleDebug` bem-sucedido neste ambiente. É necessário o GitHub Actions com acesso à rede, JDK/SDK e resolução das dependências.
2. **Teste físico:** microfone, áudio, wake word, serviço em segundo plano, notificações, alarmes exatos, reinício do aparelho, telas pequenas e permissões devem ser testados em Android real.
3. **Ciclo de vida da wake word:** o detector é gerenciado pelo plugin ligado à atividade. O serviço em primeiro plano mantém uma notificação, mas não transfere a propriedade do detector para o serviço. Portanto, o comportamento depois de encerrar/remover a atividade não deve ser anunciado como garantido até uma refatoração e teste específico.
4. **Permissões Android:** Android 12+ pode exigir permissão para alarmes exatos; Android 13+ usa permissão de notificação; restrições de serviço em primeiro plano variam por versão/fabricante.
5. **Licença do modelo:** os modelos pré-treinados de wake word openWakeWord têm licença CC BY-NC-SA 4.0. Avalie a licença antes de distribuir comercialmente; o código da biblioteca e o modelo não têm necessariamente a mesma licença.
6. **Escopo funcional:** não há automação universal de qualquer app, chamadas WhatsApp totalmente automáticas, envio silencioso de áudio nem rastreamento automático do último app externo. A conversa WhatsApp abre pelo número salvo; o usuário conclui a chamada ou áudio no WhatsApp.
7. **Testes comportamentais:** os testes atuais cobrem sintaxe e invariantes, não substituem testes de interface ponta a ponta com APIs reais, permissões e dispositivo.

## Revisão adicional de publicação no GitHub

Foi confirmado um detalhe importante de implantação: o arquivo `build-apk.yml` dentro do ZIP está em `JARVIS-NOVA/.github/workflows/`, portanto o GitHub Actions **não ativa esse workflow se você enviar somente o ZIP para um repositório vazio**. O workflow precisa existir também no caminho `.github/workflows/build-apk.yml` na raiz do repositório. Para evitar esse bloqueio, foi preparado um pacote separado para publicação contendo o ZIP-fonte e o workflow no caminho correto.

## Conclusão

A fonte está mais preparada e tem testes estáticos aprovados, mas **não pode ser declarada livre de defeitos nem pronta para instalação antes do build real e dos testes no Android**. O próximo marco de aceitação é: workflow verde, APK presente no artefato, instalação bem-sucedida e checklist manual concluído.
