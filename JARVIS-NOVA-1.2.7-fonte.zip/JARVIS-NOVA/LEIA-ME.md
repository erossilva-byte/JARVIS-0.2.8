# J.A.R.V.I.S. Nova 1.2.7

Evolução baseada exclusivamente no fonte 1.2.5 fornecido. Mantém o aplicativo independente com `com.jarvis.nova`.

## Destaques desta revisão

- Detecção local openWakeWord com modelo “Hey Jarvis”, sem AccessKey de wake word.
- Mini-interface de ativação.
- Painel do celular com bateria, temperatura reportada pela bateria, armazenamento, RAM, conexão e atalhos do Android.
- Links oficiais para cadastrar chaves de IA; cotas gratuitas variam por provedor.
- Humor configurável (0–100%) e estilo de resposta equilibrado, formal, amigável ou técnico.
- Comando por voz para abrir a conversa WhatsApp de um contato cadastrado; envio de áudio e chamadas continuam sendo concluídos pelo usuário no WhatsApp.
- Atalhos para aplicativos comuns, mídia, tarefas, rotinas, alarmes e modo offline herdados da base 1.2.5.

## Gerar APK

Envie `JARVIS-NOVA-1.2.7-fonte.zip` para a raiz do repositório e faça commit na `main`. O workflow de Actions executará os testes, configurará a API mínima 26 e tentará compilar o APK. Consulte `CHECKLIST-PARA-GERAR-APK-1.2.7.md`.

## Limites e privacidade

O detector precisa analisar áudio local enquanto estiver habilitado; o indicador de microfone do Android pode permanecer ativo. O modelo atual reconhece “Hey Jarvis” em inglês, e a precisão em português precisa de teste físico. A licença do modelo pré-treinado é CC BY-NC-SA 4.0, portanto avalie-a antes de distribuir comercialmente. O Android não concede controle irrestrito de todos os apps; mensagens e chamadas continuam sujeitas a confirmação. Temperatura significa a leitura que o sistema reporta para a bateria.

## Estado real

Os testes estáticos passaram, incluindo a validação do patch Gradle e da API mínima 26. A compilação Gradle e os testes em dispositivo ainda não foram concluídos. Não considere o APK pronto até o Actions produzir o artefato da versão 1.2.7 e o arquivo ser instalado/testado.


### Ajustes finais antes do APK

- A biblioteca de ativação local exige Android 8.0/API 26 ou superior; o patch Gradle agora aplica esse mínimo.
- Teste automatizado confirma que o patch da dependência e do repositório JitPack pode ser aplicado mais de uma vez sem duplicar entradas.
- A validação estática não substitui a compilação real nem o teste físico.

### Revisão 1.2.7

Inclui controles de humor/estilo e comando para abrir uma conversa WhatsApp com contato cadastrado. Ações de chamada, áudio e envio exigem revisão no próprio WhatsApp. Não equivale a controle irrestrito de aplicativos.
