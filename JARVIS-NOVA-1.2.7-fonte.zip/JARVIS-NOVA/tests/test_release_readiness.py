"""Verificações adicionais de preparação para o build Android do J.A.R.V.I.S. Nova."""
from html.parser import HTMLParser
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
issues = []

class Parser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get('id'):
            self.ids.append(values['id'])

html = (ROOT / 'index.html').read_text(encoding='utf-8')
parser = Parser()
parser.feed(html)
if len(parser.ids) != len(set(parser.ids)):
    issues.append('HTML contém IDs duplicados')
app = (ROOT / 'app.js').read_text(encoding='utf-8')
for target in re.findall(r"\$\(['\"]#([A-Za-z][A-Za-z0-9_-]*)['\"]\)", app):
    if target not in parser.ids and target not in {
        'rt-arg-dia','rt-arg-app','rt-arg-consulta','rt-arg-numero','rt-arg-texto',
        'rt-arg-contato','rt-arg-modo','rt-arg-valor','rt-arg-hora'
    }:
        issues.append(f'app.js seleciona ID inexistente: #{target}')
        break

workflow = (ROOT / '.github/workflows/build-apk.yml').read_text(encoding='utf-8')
extract = next((line.strip() for line in workflow.splitlines() if 'find "$SRC"' in line), '')
if not extract.endswith('\\;') or extract.endswith('\\\\;'):
    issues.append('Comando find do workflow tem escape incorreto; pode interromper a extração do ZIP')
for required in ['JARVIS-NOVA-1.2.7-fonte.zip', 'npm run test:all', 'python3 patch_manifest.py', 'python3 patch_gradle.py', './gradlew assembleDebug', 'JARVIS-Nova-1.2.7-APK']:
    if required not in workflow:
        issues.append(f'Workflow não contém etapa obrigatória: {required}')

version = json.loads((ROOT / 'VERSAO.json').read_text(encoding='utf-8'))
pkg = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))
cap = json.loads((ROOT / 'capacitor.config.json').read_text(encoding='utf-8'))
if pkg.get('version') != version.get('version'):
    issues.append('package.json e VERSAO.json têm versões diferentes')
if cap.get('appId') != version.get('androidAppId'):
    issues.append('capacitor.config.json e VERSAO.json têm appId diferente')
if version.get('version') != '1.2.7' or version.get('versionCode') != 1207:
    issues.append('Versão de auditoria esperada: 1.2.7 / 1207')

if 'aguardando "Hey Jarvis"' not in app or 'Ouvindo “Hey Jarvis”' not in app:
    issues.append('Rótulos da interface não correspondem à palavra de ativação configurada')
if "if (ehAndroid) {\n    if (!s || typeof s.guardarSeguro !== 'function') throw new Error('Cofre seguro do Android indisponível." not in app:
    issues.append('Armazenamento de chaves não falha fechado no Android')
if "$('#c-salvar').onclick = () => salvarConfig().catch" not in app:
    issues.append('Falhas ao salvar configurações não são apresentadas ao usuário')

# O script de versão deve poder ser executado novamente sem falhar se já estiver correto.
patch = (ROOT / 'patch_android_version.py').read_text(encoding='utf-8')
if 'version já está correta' not in patch:
    issues.append('Patch de versão não é idempotente')

if issues:
    print('FALHA na auditoria de prontidão:')
    for item in issues:
        print(' - ' + item)
    sys.exit(1)
print(f'Prontidão estática OK: {len(parser.ids)} IDs HTML únicos; workflow de extração/build; cofre de chaves Android; rótulos Hey Jarvis; versão {version["version"]}.')
