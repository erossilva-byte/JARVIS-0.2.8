"""Adiciona openWakeWord Android e o repositório JitPack ao projeto Capacitor."""
import re
import sys
from pathlib import Path

app_gradle = Path(sys.argv[1])
app_text = app_gradle.read_text(encoding="utf-8")
coordinate = 'implementation "com.github.msnilsen:openwakeword-android:0.1.0"'

# openWakeWord Android requires API 26+. Override the Capacitor template's
# default minSdk inside defaultConfig so older devices do not install an app
# that cannot run its wake-word detector.
default_config = re.search(r"\bdefaultConfig\s*\{", app_text)
if not default_config:
    raise SystemExit(f"Bloco defaultConfig {{ não encontrado em {app_gradle}")
start_cfg = default_config.end() - 1
level_cfg = 0
end_cfg = None
for i in range(start_cfg, len(app_text)):
    if app_text[i] == "{": level_cfg += 1
    elif app_text[i] == "}":
        level_cfg -= 1
        if level_cfg == 0:
            end_cfg = i
            break
if end_cfg is None:
    raise SystemExit(f"Bloco defaultConfig incompleto em {app_gradle}")
config_block = app_text[start_cfg:end_cfg + 1]
if re.search(r"(?m)^\s*minSdkVersion\s+26\s*$", config_block):
    print("minSdkVersion 26 já configurado")
elif re.search(r"(?m)^\s*minSdkVersion(?:\s*=)?\s+[^\n]+", config_block):
    config_block = re.sub(r"(?m)^(\s*)minSdkVersion(?:\s*=)?\s+[^\n]+", r"\g<1>minSdkVersion 26", config_block, count=1)
    app_text = app_text[:start_cfg] + config_block + app_text[end_cfg + 1:]
    print("minSdkVersion ajustado para 26 (Android 8.0+)")
else:
    config_block = config_block[:-1] + "    minSdkVersion 26\n}"
    app_text = app_text[:start_cfg] + config_block + app_text[end_cfg + 1:]
    print("minSdkVersion 26 adicionado (Android 8.0+)")
if coordinate not in app_text:
    match = re.search(r"\bdependencies\s*\{", app_text)
    if not match:
        raise SystemExit(f"Bloco dependencies {{ não encontrado em {app_gradle}")
    start = match.end() - 1
    level = 0
    end = None
    for i in range(start, len(app_text)):
        if app_text[i] == "{": level += 1
        elif app_text[i] == "}":
            level -= 1
            if level == 0:
                end = i
                break
    if end is None:
        raise SystemExit(f"Bloco dependencies incompleto em {app_gradle}")
    app_text = app_text[:end] + "    " + coordinate + "\n" + app_text[end:]
    app_gradle.write_text(app_text, encoding="utf-8")
    print(f"Dependência openWakeWord adicionada: {app_gradle}")
else:
    print(f"Dependência openWakeWord já presente: {app_gradle}")

# Persist both the SDK-floor adjustment and dependency changes on every run.
app_gradle.write_text(app_text, encoding="utf-8")

settings = app_gradle.parent.parent / "settings.gradle"
if not settings.exists():
    settings = app_gradle.parent.parent / "settings.gradle.kts"
if not settings.exists():
    raise SystemExit(f"Não encontrei settings.gradle(.kts) junto de {app_gradle}")
settings_text = settings.read_text(encoding="utf-8")
if "https://jitpack.io" not in settings_text:
    # Dependency coordinates must be resolved from dependencyResolutionManagement,
    # not merely from pluginManagement repositories.
    scope = re.search(r"dependencyResolutionManagement\s*\{[\s\S]*?repositories\s*\{", settings_text)
    if not scope:
        scope = re.search(r"repositories\s*\{", settings_text)
    if not scope:
        raise SystemExit(f"Bloco repositories {{ não encontrado em {settings}")
    insertion = scope.end()
    repo_line = '\n        maven { url = uri("https://jitpack.io") }' if settings.suffix == ".kts" else '\n        maven { url "https://jitpack.io" }'
    settings_text = settings_text[:insertion] + repo_line + settings_text[insertion:]
    settings.write_text(settings_text, encoding="utf-8")
    print(f"Repositório JitPack adicionado: {settings}")
else:
    print(f"Repositório JitPack já presente: {settings}")
